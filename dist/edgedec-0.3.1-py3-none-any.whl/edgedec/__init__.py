from .picture_class import Picture
print('Import successfully')
# Correct
